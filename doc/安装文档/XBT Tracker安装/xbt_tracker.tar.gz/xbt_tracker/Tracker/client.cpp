#include "stdafx.h"
#include "client.h"

Cclient::~Cclient()
{
}
