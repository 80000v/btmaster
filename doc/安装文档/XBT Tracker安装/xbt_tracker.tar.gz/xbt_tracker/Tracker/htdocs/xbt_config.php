<?php
	$mysql_host = 'localhost';
	$mysql_user = 'xbt';
	$mysql_pass = '';
	$mysql_db = 'xbt';
?>
