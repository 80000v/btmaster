#if !defined(AFX_BROWSE_FOR_DIRECTORY_H__4824D797_A4C6_4D58_A45F_F32B3D81F6C3__INCLUDED_)
#define AFX_BROWSE_FOR_DIRECTORY_H__4824D797_A4C6_4D58_A45F_F32B3D81F6C3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

int browse_for_directory(HWND, const std::string& title, std::string& directory);

#endif // !defined(AFX_BROWSE_FOR_DIRECTORY_H__4824D797_A4C6_4D58_A45F_F32B3D81F6C3__INCLUDED_)
